rm -rf *gofr*
rm -rf *gave*
rm -rf *epot*
rm -rf *pres*
rm -rf frames/*.xyz
rm -rf seed.out
rm -rf config.final
